Thank you for downloading and using our projects!! Stay connected and Keep supporting us by sharing it with your friends,family and all who needs it. Happy Learning! :)

**************************************[Genie Projects World]********************************************

Project Name: Online Blood Bank System

Developed By: GPW Team

Summary: This project was created to facilitate both blood receivers and Hospitals in times of any emergency needs. Here Hospitals can add available blood samples to their blood bank and blood receiving users can request for that blood sample thru this sytem.
 
Technologies Used: HTML, CSS, Bootstrap, JavaScript for frontend, PHP as a backend and MySQL for the database.

Features:
-->Simple and elegant UI
-->User-Friendly Interface
-->Easy to make request for blood samples from your desired hospital
-->Provides all hospitals blood samples availability information at one place
-->Contains all essential functionalities
-->Fully customizable
-->Compact in size

IMPORTANT NOTE: Use only for Educational Purposes!

******************************************************************************************************

Check our channel for more Projects!
