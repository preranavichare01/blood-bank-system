# Bloodbank
<b>This repository is created for the bloodbank management system project in DBMS </b>
